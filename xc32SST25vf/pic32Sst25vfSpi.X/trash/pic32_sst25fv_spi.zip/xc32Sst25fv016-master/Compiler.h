/* 
 * File:   Compiler.h
 * Author: optimus
 *
 * Created on 18 de julio de 2017, 22:07
 */

#ifndef COMPILER_H
#define	COMPILER_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <p32xxxx.h>
#include <plib.h>


#ifdef	__cplusplus
}
#endif

#endif	/* COMPILER_H */

